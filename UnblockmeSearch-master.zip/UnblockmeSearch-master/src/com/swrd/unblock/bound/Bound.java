package com.swrd.unblock.bound;

import java.awt.Rectangle;

public interface Bound {
	Rectangle getBound();
}
