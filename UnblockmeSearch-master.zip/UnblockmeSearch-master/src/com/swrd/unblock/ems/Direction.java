package com.swrd.unblock.ems;

public enum Direction {
	Left, Right, Up, Down
};