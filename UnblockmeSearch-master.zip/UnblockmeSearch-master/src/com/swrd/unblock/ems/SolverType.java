package com.swrd.unblock.ems;

public enum SolverType {
	DFS, BFS, Astar, IDFS, IAstar
}
