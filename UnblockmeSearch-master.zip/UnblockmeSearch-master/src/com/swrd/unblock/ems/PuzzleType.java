package com.swrd.unblock.ems;

public enum PuzzleType {
	UnBlockMe, HRRoad, P9
}
