package com.swrd.unblock.ems;

public enum BlockType {
	HOR, VER, BOTH
};