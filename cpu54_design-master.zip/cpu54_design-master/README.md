# cpu54_design
It‘s a single cpu composing 54 instruction for a task in computer compositon !
